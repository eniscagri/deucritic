<?php
$host = 'localhost';
$db = 'okulSozluk'; 
$user = 'root';
$pass = '';

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Bağlantı hatası: " . $conn->connect_error);
}

function getUserName($conn, $user_id) {
    $stmt = $conn->prepare("SELECT username FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($username);
    if ($stmt->fetch()) {
        return htmlspecialchars($username);
    }
    return "Bilinmeyen";
}

$sql = "SELECT id, user_id, feature, date FROM request ORDER BY date DESC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>İstek ve Özellik Talepleri</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen">
    <div class="container mx-auto py-10">
        <h2 class="text-2xl font-bold text-center mb-8 text-gray-800">Kullanıcı İstek ve Özellik Talepleri</h2>
        <div class="overflow-x-auto rounded-lg shadow bg-white">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Kullanıcı</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">İstek / Özellik</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tarih</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                <?php if ($result && $result->num_rows > 0): ?>
                    <?php while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700"><?php echo $row['id']; ?></td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm">
                                <?php
                                    $username = getUserName($conn, $row['user_id']);
                                    $stmt = $conn->prepare("SELECT email FROM users WHERE id = ?");
                                    $stmt->bind_param("i", $row['user_id']);
                                    $stmt->execute();
                                    $stmt->bind_result($email);
                                    $emailText = ($stmt->fetch()) ? htmlspecialchars($email) : "Bilinmeyen";
                                    $stmt->close();
                                    echo '<span class="font-semibold text-gray-800">' . $username . '</span><br><span class="text-xs text-gray-500">' . $emailText . '</span>';
                                ?>
                            </td>
                            <td class="px-6 py-4 whitespace-pre-line text-sm text-gray-700"><?php echo htmlspecialchars($row['feature']); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo $row['date']; ?></td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="4" class="px-6 py-8 text-center text-gray-400">Henüz bir istek yok.</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="flex justify-center mt-8">
            <a href="dashboard.php" class="bg-green-600 text-white px-6 py-2 rounded shadow hover:bg-green-700 transition font-semibold">
                Panel'e Git
            </a>
        </div>
    </div>
</body>
</html>
<?php
$conn->close();
?>