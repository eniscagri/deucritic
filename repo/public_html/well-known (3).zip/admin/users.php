<?php

$mysqli = new mysqli("localhost", "root", "", "okulSozluk");
if ($mysqli->connect_errno) {
    die("Veritabanı bağlantı hatası: " . $mysqli->connect_error);
}

if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $mysqli->query("DELETE FROM users WHERE id = $id");
    header("Location: users.php");
    exit;
}

$result = $mysqli->query("SELECT id, username, email, school, grade_level, created_at FROM users ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Kullanıcı Yönetimi</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 min-h-screen">
    <div class="container mx-auto px-4 py-8">
        <h1 class="text-3xl font-bold mb-8 text-center text-gray-800">Kullanıcılar</h1>
        <div class="overflow-x-auto shadow rounded-lg bg-white mb-10">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">ID</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Kullanıcı Adı</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Email</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Okul</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Sınıf</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Oluşturulma</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">İşlem</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td class="px-4 py-2"><?= htmlspecialchars($row['id']) ?></td>
                        <td class="px-4 py-2"><?= htmlspecialchars($row['username']) ?></td>
                        <td class="px-4 py-2"><?= htmlspecialchars($row['email']) ?></td>
                        <td class="px-4 py-2"><?= htmlspecialchars($row['school']) ?></td>
                        <td class="px-4 py-2"><?= htmlspecialchars($row['grade_level']) ?></td>
                        <td class="px-4 py-2"><?= htmlspecialchars($row['created_at']) ?></td>
                        <td class="px-4 py-2">
                            <a href="users.php?delete=<?= $row['id'] ?>"
                               onclick="return confirm('Silmek istediğinize emin misiniz?')"
                               class="text-red-600 hover:text-red-800 font-semibold transition"
                            >Sil</a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>

        <div class="overflow-x-auto shadow rounded-lg bg-white mb-10">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th colspan="3" class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Kullanıcı</th>
                        <th colspan="2" class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Son Paylaşım Başlığı</th>
                        <th colspan="2" class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Paylaşım Tarihi</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Git</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php
                    $userResult = $mysqli->query("SELECT id, username FROM users ORDER BY id DESC");
                    while ($user = $userResult->fetch_assoc()):
                        $topicResult = $mysqli->query("SELECT id, title, created_at FROM topics WHERE created_by = " . intval($user['id']) . " ORDER BY created_at DESC LIMIT 1");
                        $topic = $topicResult->fetch_assoc();
                    ?>
                    <tr>
                        <td colspan="3" class="px-4 py-2"><?= htmlspecialchars($user['username']) ?></td>
                        <td colspan="2" class="px-4 py-2"><?= $topic ? htmlspecialchars($topic['title']) : '-' ?></td>
                        <td colspan="2" class="px-4 py-2"><?= $topic ? htmlspecialchars($topic['created_at']) : '-' ?></td>
                        <td class="px-4 py-2">
                            <?php if ($topic): ?>
                                <a href="../topic.php?id=<?= $topic['id'] ?>" target="_blank"
                                   class="inline-block bg-blue-600 text-white px-3 py-1 rounded hover:bg-blue-700 transition"
                                ><?php echo $user['username'] ?>'in Gönderisine Git</a>
                            <?php else: ?>
                                <span class="text-gray-400">-</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>

        <div class="mt-8 flex justify-center">
            <a href="dashboard.php" class="inline-block bg-green-600 text-white px-5 py-2 rounded shadow hover:bg-green-700 transition font-semibold">
                Panel'e Git
            </a>
        </div>
    </div>
</body>
</html>
<?php
$mysqli->close();
?>
