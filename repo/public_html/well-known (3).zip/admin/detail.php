<?php
$mysqli = new mysqli("localhost", "root", "", "okulSozluk");
if ($mysqli->connect_errno) {
    die("Veritabanı bağlantı hatası: " . $mysqli->connect_error);
}
if (!isset($_GET['id'])) {
    die("Kullanıcı ID belirtilmemiş.");
}
$id = intval($_GET['id']);
$result = $mysqli->query("SELECT id, username, email, school, grade_level, created_at FROM users WHERE id = $id");
if ($result->num_rows === 0) {
    die("Kullanıcı bulunamadı.");
}
$user = $result->fetch_assoc();
?><!DOCTYPE html>
<html lang="tr"></html>
<head>
    <meta charset="UTF-8">
    <title>Kullanıcı Detayları</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen">
    <div class="max-w-3xl mx-auto mt-10 bg-white rounded-lg shadow p-8">
        <h1 class="text-2xl font-bold mb-6 text-gray-800">Kullanıcı Detayları</h1>
        <table class="w-full mb-8 border border-gray-200 rounded overflow-hidden">
            <tbody>
                <tr class="border-b">
                    <th class="text-left px-4 py-2 bg-gray-50 w-1/3">ID</th>
                    <td class="px-4 py-2"><?= htmlspecialchars($user['id']) ?></td>
                </tr>
                <tr class="border-b">
                    <th class="text-left px-4 py-2 bg-gray-50">Kullanıcı Adı</th>
                    <td class="px-4 py-2"><?= htmlspecialchars($user['username']) ?></td>
                </tr>
                <tr class="border-b">
                    <th class="text-left px-4 py-2 bg-gray-50">Email</th>
                    <td class="px-4 py-2"><?= htmlspecialchars($user['email']) ?></td>
                </tr>
                <tr class="border-b">
                    <th class="text-left px-4 py-2 bg-gray-50">Okul</th>
                    <td class="px-4 py-2"><?= htmlspecialchars($user['school']) ?></td>
                </tr>
                <tr class="border-b">
                    <th class="text-left px-4 py-2 bg-gray-50">Sınıf</th>
                    <td class="px-4 py-2"><?= htmlspecialchars($user['grade_level']) ?></td>
                </tr>
                <tr>
                    <th class="text-left px-4 py-2 bg-gray-50">Oluşturulma Tarihi</th>
                    <td class="px-4 py-2"><?= htmlspecialchars($user['created_at']) ?></td>
                </tr>
            </tbody>
        </table>

        <h2 class="text-xl font-semibold mb-4 text-gray-700">Son Paylaşımlar</h2>
        <table class="w-full mb-8 border border-gray-200 rounded overflow-hidden">
            <thead>
                <tr class="bg-gray-50">
                    <th class="px-4 py-2 text-left">ID</th>
                    <th class="px-4 py-2 text-left">Başlık</th>
                    <th class="px-4 py-2 text-left">Tarih</th>
                </tr>
            </thead>
            <tbody>
            <?php
            $topicsResult = $mysqli->query("SELECT id, title, created_at FROM topics WHERE created_by = $id ORDER BY created_at DESC LIMIT 5");
            if ($topicsResult && $topicsResult->num_rows > 0) {
                while ($topic = $topicsResult->fetch_assoc()) {
                    echo "<tr class='border-b hover:bg-gray-50'>";
                    echo "<td class='px-4 py-2'>" . htmlspecialchars($topic['id']) . "</td>";
                    echo "<td class='px-4 py-2'>" . htmlspecialchars($topic['title']) . "</td>";
                    echo "<td class='px-4 py-2'>" . htmlspecialchars($topic['created_at']) . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='3' class='px-4 py-2 text-center text-gray-500'>Bu kullanıcıya ait paylaşım bulunamadı.</td></tr>";
            }
            ?>
            </tbody>
        </table>

        <h2 class="text-xl font-semibold mb-4 text-gray-700">Son İstekler</h2>
        <table class="w-full mb-8 border border-gray-200 rounded overflow-hidden">
            <thead>
                <tr class="bg-gray-50">
                    <th class="px-4 py-2 text-left">ID</th>
                    <th class="px-4 py-2 text-left">İstek / Özellik</th>
                    <th class="px-4 py-2 text-left">Tarih</th>
                </tr>
            </thead>
            <tbody>
            <?php
            $requestsResult = $mysqli->query("SELECT id, feature, date FROM request WHERE user_id = $id ORDER BY date DESC LIMIT 5");
            if ($requestsResult && $requestsResult->num_rows > 0) {
                while ($request = $requestsResult->fetch_assoc()) {
                    echo "<tr class='border-b hover:bg-gray-50'>";
                    echo "<td class='px-4 py-2'>" . htmlspecialchars($request['id']) . "</td>";
                    echo "<td class='px-4 py-2'>" . htmlspecialchars($request['feature']) . "</td>";
                    echo "<td class='px-4 py-2'>" . htmlspecialchars($request['date']) . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='3' class='px-4 py-2 text-center text-gray-500'>Bu kullanıcıya ait istek bulunamadı.</td></tr>";
            }
            ?>
            </tbody>
        </table>

        <div class="flex flex-col md:flex-row gap-4 justify-between mt-8">
            <a href="users.php" class="inline-block bg-blue-600 text-white px-5 py-2 rounded shadow hover:bg-blue-700 transition font-semibold text-center">
                Kullanıcılara Dön
            </a>
            <a href="index.php" class="inline-block bg-gray-600 text-white px-5 py-2 rounded shadow hover:bg-gray-700 transition font-semibold text-center">
                Admin Paneline Dön
            </a>
            <a href="dashboard.php" class="inline-block bg-green-600 text-white px-5 py-2 rounded shadow hover:bg-green-700 transition font-semibold text-center">
                Panel'e Git
            </a>
        </div>
    </div>
</body>
</html>
<?php
$mysqli->close();
?>
