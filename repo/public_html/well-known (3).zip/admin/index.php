<?php
$mysqli = new mysqli("localhost", "deucditiccom_eniscagri", "Enis07654607", "deucditiccom_deucritic");
if ($mysqli->connect_errno) {
    die("Veritabanı bağlantı hatası: " . $mysqli->connect_error);
}

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}
session_start();
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$loginResult = $mysqli->query(
    "SELECT u.id, u.username, l.last_login, l.last_ip 
     FROM users u 
     LEFT JOIN (
        SELECT user_id, MAX(login_time) as last_login, 
               SUBSTRING_INDEX(GROUP_CONCAT(ip_address ORDER BY login_time DESC), ',', 1) as last_ip 
        FROM logins 
        GROUP BY user_id
     ) l ON u.id = l.user_id 
     ORDER BY l.last_login DESC 
     LIMIT 10"
);
if (!$loginResult) {
    die("Sorgu hatası: " . $mysqli->error);
}
if ($loginResult->num_rows === 0) {
    echo "<div class='text-center text-gray-500 mt-10'>Kayıt bulunamadı.</div>";
    exit;
}
// HTML çıktısı
header('Content-Type: text/html; charset=utf-8');
if ($loginResult->num_rows === 0) {
    echo "<div class='text-center text-gray-500 mt-10'>Kayıt bulunamadı.</div>";
    exit;
}


?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Son Giriş Yapan Kullanıcılar</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 min-h-screen">
    <div class="container mx-auto mt-10 px-4">
        <div class="flex items-center justify-between mb-6">
            <h2 class="text-2xl font-bold text-gray-800">Son Giriş Yapan Kullanıcılar</h2>
            <a href="users.php" class="inline-block bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition">Tüm Kullanıcılar</a>
        </div>
        <div class="overflow-x-auto shadow-lg rounded-lg bg-white">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="py-3 px-6 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Kullanıcı Adı</th>
                        <th class="py-3 px-6 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Son Giriş Tarihi</th>
                        <th class="py-3 px-6 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Son IP Adresi</th>
                        <th class="py-3 px-6 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Detay</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php
                    $loginResult = $mysqli->query(
                        "SELECT u.id, u.username, l.last_login, l.last_ip 
                         FROM users u 
                         LEFT JOIN (
                            SELECT user_id, MAX(login_time) as last_login, 
                                   SUBSTRING_INDEX(GROUP_CONCAT(ip_address ORDER BY login_time DESC), ',', 1) as last_ip 
                            FROM logins 
                            GROUP BY user_id
                         ) l ON u.id = l.user_id 
                         ORDER BY l.last_login DESC 
                         LIMIT 10"
                    );
                    if ($loginResult && $loginResult->num_rows > 0):
                        while ($login = $loginResult->fetch_assoc()):
                    ?>
                    <tr class="hover:bg-gray-50 transition">
                        <td class="py-3 px-6"><?= htmlspecialchars($login['username']) ?></td>
                        <td class="py-3 px-6"><?= $login['last_login'] ? htmlspecialchars($login['last_login']) : '-' ?></td>
                        <td class="py-3 px-6"><?= $login['last_ip'] ? htmlspecialchars($login['last_ip']) : '-' ?></td>
                        <td class="py-3 px-6">
                            <a href="detail.php?id=<?= urlencode($login['id']) ?>" class="text-blue-600 hover:underline">Detay</a>
                        </td>
                    </tr>
                    <?php
                        endwhile;
                    else:
                    ?>
                    <tr>
                        <td colspan="4" class="py-4 px-6 text-center text-gray-500">Kayıt bulunamadı.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            
        </div>
    </div>
        <div class="mt-8 flex justify-center">
            <a href="dashboard.php" class="inline-block bg-green-600 text-white px-5 py-2 rounded shadow hover:bg-green-700 transition font-semibold">
                Panel'e Git
            </a>
        </div>

</body>
</html>