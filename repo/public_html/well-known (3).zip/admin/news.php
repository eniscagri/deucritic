<?php
session_start();

$host = 'localhost';
$db = 'okulSozluk';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    exit('Veritabanı bağlantı hatası: ' . $e->getMessage());
}

// CSRF Token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

// Duyuru Silme
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'], $_POST['csrf_token']) && $_POST['csrf_token'] === $csrf_token) {
    $delete_id = (int)$_POST['delete_id'];
    $pdo->prepare("DELETE FROM news WHERE id = ?")->execute([$delete_id]);
    header("Location: news.php");
    exit;
}

// Duyuru Güncelleme
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_id'], $_POST['csrf_token']) && $_POST['csrf_token'] === $csrf_token) {
    $edit_id = (int)$_POST['edit_id'];
    $author = $_POST['author'] ?? '';
    $title = $_POST['title'] ?? '';
    $news = $_POST['news'] ?? '';
    $books = $_POST['books'] ?? '';
    $pdo->prepare("UPDATE news SET author=?, title=?, news=?, books=? WHERE id=?")
        ->execute([$author, $title, $news, $books, $edit_id]);
    header("Location: news.php");
    exit;
}

// Duyuru Ekleme
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_news'], $_POST['csrf_token']) && $_POST['csrf_token'] === $csrf_token) {
    $author = $_POST['author'] ?? '';
    $title = $_POST['title'] ?? '';
    $news = $_POST['news'] ?? '';
    $books = $_POST['books'] ?? '';
    $created_at = date('Y-m-d H:i:s');
    $stmt = $pdo->prepare("INSERT INTO news (author, title, news, books, views, created_at) VALUES (?, ?, ?, ?, 0, ?)");
    $stmt->execute([$author, $title, $news, $books, $created_at]);
    header("Location: news.php");
    exit;
}

// Duyuru Görüntüleme
if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $pdo->prepare("UPDATE news SET views = views + 1 WHERE id = ?")->execute([$id]);
    $stmt = $pdo->prepare("SELECT * FROM news WHERE id = ?");
    $stmt->execute([$id]);
    $announcement = $stmt->fetch();
    if (!$announcement) {
        echo "Duyuru bulunamadı.";
        exit;
    }
    ?>
    <!DOCTYPE html>
    <html lang="tr">
    <head>
        <meta charset="UTF-8">
        <title><?php echo htmlspecialchars($announcement['title']); ?> - Duyuru</title>
        <script src="https://cdn.tailwindcss.com"></script>
    </head>
    <body class="bg-gray-100 min-h-screen flex items-center justify-center">
        <div class="bg-white shadow-lg rounded-lg p-8 max-w-xl w-full">
            <h2 class="text-2xl font-bold mb-4 text-blue-700"><?php echo htmlspecialchars($announcement['title']); ?></h2>
            <p class="mb-2"><span class="font-semibold text-gray-700">Yazar:</span> <?php echo htmlspecialchars($announcement['author']); ?></p>
            <div class="mb-4 text-gray-800"><?php echo nl2br(htmlspecialchars($announcement['news'])); ?></div>
            <?php if ($announcement['books']): ?>
                <p class="mb-2"><span class="font-semibold text-gray-700">Kitaplar:</span> <?php echo htmlspecialchars($announcement['books']); ?></p>
            <?php endif; ?>
            <p class="mb-2"><span class="font-semibold text-gray-700">Görüntülenme:</span> <?php echo $announcement['views'] + 1; ?></p>
            <a href="news.php" class="inline-block mt-4 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition">Geri dön</a>
        </div>
    </body>
    </html>
    <?php
    exit;
}

// Duyuru Düzenleme Formu
if (isset($_GET['edit'])) {
    $edit_id = (int)$_GET['edit'];
    $stmt = $pdo->prepare("SELECT * FROM news WHERE id = ?");
    $stmt->execute([$edit_id]);
    $edit_news = $stmt->fetch();
    if (!$edit_news) {
        echo "Duyuru bulunamadı.";
        exit;
    }
}

$stmt = $pdo->query("SELECT * FROM news ORDER BY created_at DESC");
$newsList = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Duyurular</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen">
    <div class="container mx-auto py-10">
        <div class="max-w-2xl mx-auto bg-white shadow-lg rounded-lg p-8 mb-8">
            <h1 class="text-2xl font-bold mb-6 text-blue-700">
                <?php echo isset($edit_news) ? "Duyuru Düzenle" : "Duyuru Ekle"; ?>
            </h1>
            <form method="post" class="space-y-4">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <?php if (isset($edit_news)): ?>
                    <input type="hidden" name="edit_id" value="<?php echo $edit_news['id']; ?>">
                <?php else: ?>
                    <input type="hidden" name="add_news" value="1">
                <?php endif; ?>
                <div>
                    <label class="block text-gray-700 font-semibold mb-1">Yazar</label>
                    <input type="text" name="author" required class="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-400"
                        value="<?php echo isset($edit_news) ? htmlspecialchars($edit_news['author']) : ''; ?>">
                </div>
                <div>
                    <label class="block text-gray-700 font-semibold mb-1">Başlık</label>
                    <input type="text" name="title" required class="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-400"
                        value="<?php echo isset($edit_news) ? htmlspecialchars($edit_news['title']) : ''; ?>">
                </div>
                <div>
                    <label class="block text-gray-700 font-semibold mb-1">Duyuru</label>
                    <textarea name="news" required class="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-400"><?php echo isset($edit_news) ? htmlspecialchars($edit_news['news']) : ''; ?></textarea>
                </div>
                <div>
                    <label class="block text-gray-700 font-semibold mb-1">Kitaplar</label>
                    <input type="text" name="books" class="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-400"
                        value="<?php echo isset($edit_news) ? htmlspecialchars($edit_news['books']) : ''; ?>">
                </div>
                <button type="submit" class="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 transition font-semibold">
                    <?php echo isset($edit_news) ? "Güncelle" : "Ekle"; ?>
                </button>
                <?php if (isset($edit_news)): ?>
                    <a href="news.php" class="block text-center mt-2 text-blue-600 hover:underline">Vazgeç</a>
                <?php endif; ?>
            </form>
        </div>

        <div class="max-w-2xl mx-auto bg-white shadow-lg rounded-lg p-8">
            <h1 class="text-2xl font-bold mb-6 text-blue-700">Duyurular</h1>
            <ul class="space-y-4">
                <?php foreach ($newsList as $item): ?>
                    <li class="border-b pb-4 last:border-b-0 flex justify-between items-start">
                        <div>
                            <a href="news.php?id=<?php echo $item['id']; ?>" class="text-lg font-semibold text-blue-600 hover:underline">
                                <?php echo htmlspecialchars($item['title']); ?>
                            </a>
                            <div class="text-sm text-gray-600 mt-1">
                                <span class="font-semibold">Yazar:</span> <?php echo htmlspecialchars($item['author']); ?> |
                                <span class="font-semibold">Görüntülenme:</span> <?php echo $item['views']; ?> |
                                <span class="font-semibold">Tarih:</span> <?php echo $item['created_at']; ?>
                            </div>
                        </div>
                        <div class="flex gap-2">
                            <a href="news.php?edit=<?php echo $item['id']; ?>" class="text-yellow-600 hover:underline">Düzenle</a>
                            <form method="post" onsubmit="return confirm('Bu duyuruyu silmek istediğinize emin misiniz?');">
                                <input type="hidden" name="delete_id" value="<?php echo $item['id']; ?>">
                                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                                <button type="submit" class="text-red-600 hover:underline">Sil</button>
                            </form>
                        </div>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
</body>
</html>