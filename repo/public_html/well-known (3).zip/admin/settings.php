<?php

require_once '../includes/config.php';


// CSRF token oluştur
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$errors = [];
$success = false;

// Ayarları çek
$stmt = $pdo->query("SELECT * FROM settings LIMIT 1");
$settings = $stmt->fetch(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CSRF kontrolü
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $errors[] = "Geçersiz istek. Lütfen tekrar deneyin.";
    } else {
        $site_title = trim($_POST['site_title'] ?? '');
        $admin_email = trim($_POST['admin_email'] ?? '');

        // Doğrulama
        if ($site_title === '') {
            $errors[] = "Site başlığı boş olamaz.";
        }
        if (!filter_var($admin_email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = "Geçerli bir e-posta adresi giriniz.";
        }

        if (!$errors) {
            $update = $pdo->prepare("UPDATE settings SET site_title = ?, admin_email = ? WHERE id = ?");
            $update->execute([$site_title, $admin_email, $settings['id']]);
            $success = true;

            // Güncel ayarları tekrar çek
            $stmt = $pdo->query("SELECT * FROM settings LIMIT 1");
            $settings = $stmt->fetch(PDO::FETCH_ASSOC);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Ayarlar</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen flex flex-col items-center py-10">
    <div class="w-full max-w-xl bg-white rounded-lg shadow-lg p-8">
        <h1 class="text-2xl font-bold mb-6 text-gray-800">Site Ayarları</h1>
        <?php if ($success): ?>
            <div class="mb-4 p-3 rounded bg-green-100 text-green-700 border border-green-300">
                Ayarlar başarıyla güncellendi.
            </div>
        <?php endif; ?>
        <?php if ($errors): ?>
            <div class="mb-4 p-3 rounded bg-red-100 text-red-700 border border-red-300">
                <?php foreach ($errors as $error): ?>
                    <div><?= htmlspecialchars($error) ?></div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        <form method="post" class="space-y-5" autocomplete="off">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
            <div>
                <label class="block text-gray-700 font-medium mb-1">Site Başlığı:</label>
                <input type="text" name="site_title" value="<?= htmlspecialchars($settings['site_title'] ?? '') ?>" required
                    class="w-full px-4 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-400">
            </div>
            <div>
                <label class="block text-gray-700 font-medium mb-1">Admin E-posta:</label>
                <input type="email" name="admin_email" value="<?= htmlspecialchars($settings['admin_email'] ?? '') ?>" required
                    class="w-full px-4 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-400">
            </div>
            <button type="submit"
                class="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 rounded transition">
                Kaydet
            </button>
        </form>
        <h2 class="text-xl font-semibold mt-10 mb-4 text-gray-700">Mevcut Ayarlar</h2>
        <table class="min-w-full bg-white border border-gray-200 rounded">
            <thead>
                <tr>
                    <th class="py-2 px-4 border-b text-left text-gray-600">Site Başlığı</th>
                    <th class="py-2 px-4 border-b text-left text-gray-600">Admin E-posta</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="py-2 px-4 border-b"><?= htmlspecialchars($settings['site_title'] ?? '') ?></td>
                    <td class="py-2 px-4 border-b"><?= htmlspecialchars($settings['admin_email'] ?? '') ?></td>
                </tr>
            </tbody>
        </table>
        <div class="mt-8 text-center">
            <a href="dashboard.php"
                class="inline-block px-6 py-2 bg-gray-200 hover:bg-gray-300 text-gray-700 rounded transition">
                Geri Dön
            </a>
        </div>
    </div>
</body>
</html>
