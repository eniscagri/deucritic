<?php
session_start();
$username = "admin";

$host = "localhost";
$user = "deucditiccom_eniscagri;";
$pass = "Enis076546";
$db = "deucditiccom_deucritic";
$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Bağlantı hatası: " . $conn->connect_error);
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Paneli</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen">
    <div class="container mx-auto px-4 py-8">
        <div class="bg-white rounded-lg shadow-lg p-8">
            <h1 class="text-3xl font-bold text-gray-800 mb-6 text-center">Admin Paneli</h1>
            <nav class="mb-8">
                <ul class="flex flex-col md:flex-row justify-center gap-4">
                    <li>
                        <a href="index.php" class="text-gray-700 hover:text-blue-600 px-4 py-2 rounded transition-colors duration-200">Anasayfa</a>
                    </li>
                    <li>
                        <a href="users.php" class="text-gray-700 hover:text-blue-600 px-4 py-2 rounded transition-colors duration-200">Kullanıcılar</a>
                    </li>
                    <li>
                        <a href="posts.php" class="text-gray-700 hover:text-blue-600 px-4 py-2 rounded transition-colors duration-200">Güncellemeler</a>
                    </li>
                    <li>
                        <a href="settings.php" class="text-gray-700 hover:text-blue-600 px-4 py-2 rounded transition-colors duration-200">Ayarlar</a>
                    </li>

                    <li>
                        <a href="news.php" class="text-gray-700 hover:text-blue-600 px-4 py-2 rounded transition-colors duration-200">Haber Ekle</a>
                    </li>

                    <li>
                        <a href="logout.php" class="text-red-600 hover:bg-red-100 px-4 py-2 rounded transition-colors duration-200">Çıkış Yap</a>
                    </li>
                </ul>
            </nav>
            <div class="content text-center">
                <h2 class="text-2xl font-semibold text-gray-700 mb-2">Hoşgeldiniz, <?php echo $username; ?>!</h2>
                <p class="text-gray-600">Admin paneline giriş yaptınız.</p>
            </div>
        </div>
    </div>
</body>
</html>
